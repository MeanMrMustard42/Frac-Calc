public class FracCalc {
	public static void main(String[] args) {
		// TODO: Read the input from the user and call produceAnswer with an equation

	}
	
	/**
	 * >>> IMPORTANT <<<
	 * DO NOT DELETE THIS FUNCTION OR CHANGE ITS PARAMETER OR RETURN TYPE!
	 * This function will be used to test your code.
	 * 
	 * Takes a fraction calculation string and returns the result of the calculation.
	 * 
	 * Example: produceAnswer("1/2 + 3/4") should return "1_1/4"
	 * 
	 * @param input A fraction string that needs to be evaluated.
	 * 				For your program, this will be the user input.
	 * @return The result of the calculation
	 */
	public static String produceAnswer(String input) { 
		// TODO: Implement this function to produce the solution to the input
		
		return "";
	}

	// TODO: Fill in the space below with any helper methods that you think you will need
}
